#ifndef ABSTRACT_H
#define ABSTRACT_H

#include <QDialog>

namespace Ui {
class Abstract;
}

class Abstract : public QDialog
{
    Q_OBJECT

public:
    explicit Abstract(QWidget *parent = 0);
    ~Abstract();
signals:
    void signalSaveClicked();
protected slots:
    void slotSaveClicked();

private:
    Ui::Abstract *ui;
};

#endif // ABSTRACT_H
