#include "modify_anno.h"
#include "ui_modify_anno.h"
#include "variate.h"
#include "QFile"
#include "QTextStream"
#include "QListWidgetItem"
Modify_anno::Modify_anno(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Modify_anno)
{
    ui->setupUi(this);
    /*
    ui->add->setStyleSheet("QPushButton{font: 25 12pt '微软雅黑 Light';color: rgb(255,255,255);background-color: rgb(20,196,188);"
                           "border: 2px groove gray;border-radius:15px;padding:2px 4px;border-style: outset;}"
                           "QPushButton:hover{background-color: rgb(22,218,208);}"//hover
                           "QPushButton:pressed{background-color: rgb(17,171,164);}"//pressed
                             "border:2px solid rgb(20,196,188);");
    ui->save->setStyleSheet("QPushButton{font: 25 12pt '微软雅黑 Light';color: rgb(255,255,255);background-color: rgb(20,196,188);"
                            "border: 2px groove gray;border-radius:15px;padding:2px 4px;border-style: outset;}"
                            "QPushButton:hover{background-color: rgb(22,218,208);}"//hover
                            "QPushButton:pressed{background-color: rgb(17,171,164);}"//pressed
                              "border:2px solid rgb(20,196,188);");
    ui->conv_delete->setStyleSheet("QPushButton{font: 25 12pt '微软雅黑 Light';color: rgb(255,255,255);background-color: rgb(20,196,188);"
                                     "border: 2px groove gray;border-radius:15px;padding:2px 4px;border-style: outset;}"
                                     "QPushButton:hover{background-color: rgb(22,218,208);}"//hover
                                     "QPushButton:pressed{background-color: rgb(17,171,164);}"//pressed
                                       "border:2px solid rgb(20,196,188);");
    ui->conv_modify->setStyleSheet("QPushButton{font: 25 12pt '微软雅黑 Light';color: rgb(255,255,255);background-color: rgb(20,196,188);"
                                     "border: 2px groove gray;border-radius:15px;padding:2px 4px;border-style: outset;}"
                                     "QPushButton:hover{background-color: rgb(22,218,208);}"//hover
                                     "QPushButton:pressed{background-color: rgb(17,171,164);}"//pressed
                                       "border:2px solid rgb(20,196,188);");
    //this->setStyleSheet("background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0, stop:0 rgba(120,120,120, 200), stop:1 rgba(120,120,120, 200));");
    //this->setStyleSheet("background-color:pink");
    */

    ui->textEdit->setPlaceholderText(tr("请输入注释序号+内容，序号采用阿拉伯数字，序号后接+号,格式如例如:  1+《xxx》，xxx，2001."));
    QString path = prePath + "/anno.txt";
    QFile f(path);
    f.open(QIODevice::ReadOnly|QIODevice::Text);
    while(!f.atEnd())
    {
        QByteArray line = f.readLine();
        QString str(line);
        str = str.left(str.size()-1);
        QListWidgetItem* item = new QListWidgetItem(ui->listWidget);
        item->setText(str);
    }

    f.close();
    ui->listWidget->sortItems();
    connect(ui->save,SIGNAL(clicked()),this,SLOT(slotSaveClicked()));
}

Modify_anno::~Modify_anno()
{
    delete ui;
}





void Modify_anno::on_listWidget_itemClicked(QListWidgetItem *item)
{
    select = item;
}

void Modify_anno::on_conv_delete_clicked()
{
    if(select==nullptr) return;
    delete select;
    select = nullptr;
}

void Modify_anno::on_conv_modify_clicked()
{
    on_add_clicked();
    if(select==nullptr) return;
    QString line = select->text();
    delete select;select=nullptr;
    int pos = line.indexOf(tr("]"));
    QString num = line.mid(1,pos-1);
    line = line.mid(pos+1);
    line = num + tr("+") + line;
    ui->textEdit->setText(line);
}

void Modify_anno::on_add_clicked()
{
    QString line = ui->textEdit->toPlainText();
    if(!line.size()) return;
    line = line.remove(QRegExp("\\s"));
    int pos = line.indexOf(tr("+"));
    QString num = line.mid(0,pos);
    line = line.mid(pos+1);
    line = tr("[") + num + tr("]") + line;
    QListWidgetItem* item = new QListWidgetItem(ui->listWidget);
    item -> setText(line);
    ui->listWidget->sortItems();
    ui->textEdit->clear();
}

void Modify_anno::slotSaveClicked()
{
    QString path = prePath + "/anno.txt";
    QFile f(path);
    f.open(QIODevice::WriteOnly|QIODevice::Text);
    QTextStream out(&f);
    out.setCodec("utf-8");
    int row=0;
    while(row<(ui->listWidget->count()))
    {
        QString line = ui->listWidget->item(row)->text();
        out<<line<<endl;
        row++;
    }
    f.close();
    this->close();
}
