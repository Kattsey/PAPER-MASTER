#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "variate.h"
#include "QDebug"
#include "QVector"
#include "mwitem.h"
#include "QListWidget"
#include "QScroller"
#include "QString"
#include "signal.h"
#include "mainbody.h"
#include "qPalette"
#include "QDir"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    this->setWindowTitle("开始项目");

    //——————————————————————————————————————————————————————

   /* ui->Create_botton->setStyleSheet("QPushButton{font: 1000 20pt '微软雅黑 Light';color: rgb(255,255,255);background-color: rgb(20,196,188);"
                                     "border: 2px groove gray;border-radius:15px;padding:2px 4px;border-style: outset;}"
                                     "QPushButton:hover{background-color: rgb(22,218,208);}"//hover
                                     "QPushButton:pressed{background-color: rgb(17,171,164);}"//pressed
                                       "border:2px solid rgb(20,196,188);");
    ui->open_button->setStyleSheet("QPushButton{font: 1000 20pt '微软雅黑 Light';color: rgb(255,255,255);background-color: rgb(20,196,188);"
                                     "border: 2px groove gray;border-radius:15px;padding:2px 4px;border-style: outset;}"
                                     "QPushButton:hover{background-color: rgb(22,218,208);}"//hover
                                     "QPushButton:pressed{background-color: rgb(17,171,164);}"//pressed
                                       "border:2px solid rgb(20,196,188);");
    ui->settings_botton->setStyleSheet("QPushButton{font: 1000 20pt '微软雅黑 Light';color: rgb(255,255,255);background-color: rgb(20,196,188);"
                                     "border: 2px groove gray;border-radius:15px;padding:2px 4px;border-style: outset;}"
                                     "QPushButton:hover{background-color: rgb(22,218,208);}"//hover
                                     "QPushButton:pressed{background-color: rgb(17,171,164);}"//pressed
                                       "border:2px solid rgb(20,196,188);");*/

    //————————————————————————————————————————————————————————————---

    //Background
    //——————————————————————————————————————————————————————————————
    //this->setStyleSheet("background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0, stop:0 rgba(102,102,102, 200), stop:1 rgba(102,102,102, 210));");
    //this->setStyleSheet("background-color:pink");
    //ui->Show_Project->setStyleSheet("background-color:transparent");
    //ui->label->setStyleSheet("background-color:transparent");
    //ui->label_Projectexsist->setStyleSheet("background-color:transparent");
    //——————————————————————————————————————————————————————————————
    if(!file.exists()){
        file.open(QIODevice::WriteOnly|QIODevice::Text);
        file.write("this is the directory of all projects\n");
    }
    file.close();

    if(!file.open(QIODevice::ReadOnly|QIODevice::Text))
        return;
    QVector<QString> projectPaths;
    while(!file.atEnd()){
        QByteArray line = file.readLine();
        QString str(line);
        str = str.left(str.size()-1);
        projectPaths.append(str);
    }
    projectPaths.erase(projectPaths.begin());
    ui->Show_Project->setResizeMode(QListWidget::Adjust);
    // 设置为列表显示模式
    ui->Show_Project->setViewMode(QListView::ListMode);
    // 设置从上到下排列
    ui->Show_Project->setFlow(QListView::TopToBottom);
    // 屏蔽水平滑动条
    ui->Show_Project->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    // 屏蔽垂直滑动条
    ui->Show_Project->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    // 设置成像素滚动
    ui->Show_Project->setHorizontalScrollMode(QListWidget::ScrollPerPixel);
    // 设置鼠标左键拖动
    QScroller::grabGesture(ui->Show_Project,QScroller::LeftMouseButtonGesture);
    while(!projectPaths.empty()){//初始化所有项目列表
        QListWidgetItem* item = new QListWidgetItem(ui->Show_Project);
        item->setSizeHint(QSize(530,70));
        ui->Show_Project->addItem(item);
        QString name = projectPaths.at(0);
        QString path = projectPaths.at(1);
        projectPaths.erase(projectPaths.begin());
        projectPaths.erase(projectPaths.begin());
        MWitem* witem = new MWitem();
        witem->Init(name,path);
        //item->setText(path);
        ui->Show_Project->setItemWidget(item,witem);
    }
    hasSelected=false;
    file.close();
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_Create_botton_clicked()
{
    Create_Dialog create_dialog;
    this->close();
    create_dialog.exec();
    if(create_dialog.back)
    {
        this->show();
        create_dialog.back=false;

    }
}

void MainWindow::on_settings_botton_clicked()
{
    Settings set;
    set.exec();
}

void MainWindow::on_open_button_clicked()
{
    if(hasSelected)
    {
        Main_Menu w;
        QDir dir(prePath);
        if(!dir.exists())
            dir.mkdir(prePath);
        this->close();
        w.exec();
    }
}

void MainWindow::on_delete_button_clicked()
{
    if(hasSelected)
    {

        //先删widget
        int row=0;QString line;QString del;
        del = prePath;
        while(row<(ui->Show_Project->count()))
        {
            line = static_cast<MWitem*>(ui->Show_Project->itemWidget(ui->Show_Project->item(row)))->lb2();
            if(line==del)
            {
                ui->Show_Project->takeItem(row);
                left=nullptr;
                break;
            }
            ++row;
        }
        //再删文件（只删那两行，重新读写一遍）
        file.open(QIODevice::ReadOnly|QIODevice::Text);
        QVector<QString> projectPaths;
        while(!file.atEnd()){
            QByteArray line = file.readLine();
            QString str(line);
            str = str.left(str.size()-1);
            projectPaths.append(str);
        }
        file.close();
        file.open(QIODevice::WriteOnly|QIODevice::Text);
        file.write("this is the directory of all projects\n");
        projectPaths.erase(projectPaths.begin());
        while(!projectPaths.empty()){
            if(projectPaths.at(1)!=prePath){
                file.write(projectPaths.at(0).toUtf8().data());
                file.write("\n");
                file.write(projectPaths.at(1).toUtf8().data());
                file.write("\n");
            }
            projectPaths.erase(projectPaths.begin());
            projectPaths.erase(projectPaths.begin());
        }
        file.close();
    }
}

void MainWindow::on_Show_Project_itemClicked(QListWidgetItem *item)
{
    static_cast<MWitem*>(ui->Show_Project->itemWidget(item))->OnSelect();
    if(left!=nullptr&&left!=item)
    {
        static_cast<MWitem*>(ui->Show_Project->itemWidget(left))->OnRelease();
    }
    left = item;
}

