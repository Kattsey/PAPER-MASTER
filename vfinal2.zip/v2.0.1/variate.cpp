#include "variate.h"
#include "QString"
#include "QFile"
#include "mainwindow.h"

QString dirPath = "./directory.txt";
QFile file(dirPath);
QString prePath;
QString preName;
qreal fac;
bool hasSelected;

