#include "keyword.h"
#include "ui_keyword.h"
#include "QListWidget"
#include "QListWidgetItem"
#include "variate.h"
#include "QTextStream"
KeyWord::KeyWord(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::KeyWord)
{
    ui->setupUi(this);
    this->setWindowTitle("关键词");
    //——————————————————————————————————————————————————

    ui->Delete_edit->setPlaceholderText(tr("选择删除的关键词"));
    connect(ui->save,SIGNAL(clicked()),this,SLOT(slotSaveClicked()));
    // 设置为列表显示模式
    ui->listWidget->setViewMode(QListView::ListMode);
    // 设置从上到下排列
    ui->listWidget->setFlow(QListView::TopToBottom);
    // 屏蔽水平滑动条
    ui->listWidget->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    // 屏蔽垂直滑动条
    ui->listWidget->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    // 设置成像素滚动
    QString path;
    path = prePath + "/keywords.txt";
    QFile f(path);
    f.open(QIODevice::ReadOnly|QIODevice::Text);
    while(!f.atEnd())
    {
        QByteArray line;
        line = f.readLine();
        QString word(line);
        word = word.left(word.size()-1);
        if(word.size())
        {
            QListWidgetItem* item = new QListWidgetItem(ui->listWidget);
            item->setSizeHint(QSize(550,80));
            item->setText(word);
        }
    }
    f.close();
}

KeyWord::~KeyWord()
{
    delete ui;
}

void KeyWord::on_Add_Keyword_clicked()
{
    QString word;
    word = ui->Add_edit->text();
    if(word.size())
    {
        QListWidgetItem* item = new QListWidgetItem(ui->listWidget);
        item->setSizeHint((QSize(550,80)));
        item->setText(word);
    }
    ui->Add_edit->clear();
}
void KeyWord::slotSaveClicked()
{
    QString path;
    path = prePath + "/keywords.txt";
    QFile f(path);
    f.open(QIODevice::WriteOnly|QIODevice::Text);
    QTextStream out(&f);
    out.setCodec("utf-8");
    int row=0;QString line;
    while(row<(ui->listWidget->count()))
    {
        line = ui->listWidget->item(row)->text();
        out<<line<<endl;
        row++;
    }
    f.close();
    emit signalSaveClicked();
    this->close();
}

void KeyWord::on_listWidget_itemClicked(QListWidgetItem *item)
{
    QString content;
    content = item->text();
    ui->Delete_edit->setText(content);
}

void KeyWord::on_Delete_Keyword_clicked()
{
    int row=0;QString line;QString del;
    del = ui->Delete_edit->text();
    while(row<(ui->listWidget->count()))
    {
        line = ui->listWidget->item(row)->text();
        if(line==del)
        {
            ui->listWidget->takeItem(row);
            ui->Delete_edit->clear();
            break;
        }
        ++row;
    }
}
