#include "mwitem.h"
#include "ui_mwitem.h"
#include "variate.h"
#include "QDebug"
#include "QMouseEvent"
#include "QPalette"
#include "QPainter"

MWitem::MWitem(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::MWitem)
{
    ui->setupUi(this);
    ui->label_3->setText("");

}

MWitem::~MWitem()
{
    delete ui;
}
void MWitem::Init(QString name,QString path){
    ui->label->setText(name);
    ui->label_2->setText(path);
}
void MWitem::OnSelect()
{
    ui->label_3->setText(tr("已被选中"));
   // ui->label_3->setStyleSheet("border:2px solid yellow");
    preName = ui->label->text();
    prePath = ui->label_2->text();
    hasSelected=true;
}
void MWitem::OnRelease()
{
    ui->label_3->setText("");
    //ui->label_3->setStyleSheet("border:0px solid yellow");
}

QString MWitem::lb2()
{
    return ui->label_2->text();
}
