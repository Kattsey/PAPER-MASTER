#ifndef CREATE_DIALOG_H
#define CREATE_DIALOG_H

#include <QDialog>
#include"main_menu.h"
#include"mainwindow.h"

namespace Ui {
class Create_Dialog;
}

class Create_Dialog : public QDialog
{
    Q_OBJECT

public:
    explicit Create_Dialog(QWidget *parent = 0);
    ~Create_Dialog();
    bool back=false;//判断需不需要从create界面回来。

private slots:
    void on_Create_clicked();

    void on_Back_clicked();

    void on_viewFile_clicked();

private:
    Ui::Create_Dialog *ui;
};

#endif // CREATE_DIALOG_H
