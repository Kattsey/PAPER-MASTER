#include "author.h"
#include "ui_author.h"
#include "variate.h"
#include "QFile"
#include "QTextStream"
#include "QDebug"
Author::Author(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Author)
{
    ui->setupUi(this);
    this->setWindowTitle("作者");
        connect(ui->Save,SIGNAL(clicked()),this,SLOT(slotSaveClicked()));
        QString path;
        path = prePath+"/author.txt";
        QFile f(path);
        f.open(QIODevice::ReadOnly|QIODevice::Text);

        if(!f.atEnd())
        {
            QByteArray line;
            line = f.readLine();
            QString name(line);
            name = name.left(name.size()-1);
            ui->name->setText(name);
        }
        if(!f.atEnd())
        {
            QByteArray line;
            line = f.readLine();
            QString job(line);
            job = job.left(job.size()-1);
            ui->job->setText(job);
        }
        if(!f.atEnd())
        {
            QByteArray line;
            line = f.readLine();
            QString num(line);
            num = num.left(num.size()-1);
            ui->num->setText(num);
        }
        if(!f.atEnd())
        {
            QByteArray line;
            line = f.readLine();
            QString els(line);
            els = els.left(els.size()-1);
            ui->Else->setText(els);
        }
        f.close();
}

Author::~Author()
{
    delete ui;
}
void Author::slotSaveClicked()
{
    QString path;
    path = prePath+"/author.txt";
    QFile f(path);
    f.open(QIODevice::WriteOnly|QIODevice::Text);
    QTextStream out(&f);
    out.setCodec("utf-8");
    QString name,job,num,els;
    name = ui->name->text();
    job = ui->job->text();
    num = ui->num->text();
    els = ui->Else->text();
    if(name.size())
        out<<name<<endl;
    else
        out<<endl;
    if(job.size())
        out<<job<<endl;
    else
        out<<endl;
    if(num.size())
        out<<num<<endl;
    else
        out<<endl;
    if(els.size())
        out<<els<<endl;
    else
        out<<endl;
    f.close();
    emit signalSaveClicked();
    this->close();
}
