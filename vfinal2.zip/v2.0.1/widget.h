#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>

namespace Ui {
class Widget;
}

class Widget : public QWidget
{
    Q_OBJECT

public:
    explicit Widget(QWidget *parent = 0);
    ~Widget();
    int c11,c12,c13,c14,
    c21,c22,c23,c24,
    c31,c32,c33,c34,
    c41,c42,c43,c44,
    c51,c52,c53,c54,
    c61,c62,c63,c64,
    c71,c72,c73,c74,
    c81,c82,c83,c84,
    c91,c92,c93,c94,
    ca1,ca2,ca3,ca4,
    cb1,cb2,cb3,cb4;
    QString html;
    void addHtml(int font, int size, int bi, int align, QString content, bool noleft, bool noright);
    void saveWord();
    QString saveHtml();
    QString title;
    QString subtitle;

private:
    Ui::Widget *ui;
};

#endif // WIDGET_H
