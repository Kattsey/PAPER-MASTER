#include "widget.h"
#include "ui_widget.h"
#include "variate.h"
#include "QFile"
#include "QTextStream"
#include "QDebug"
#include "Qsize"
#include "create.h"


Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);
    html = "";
}

Widget::~Widget()
{
    delete ui;
}

QString chineseNumber[10]={"一","二","三","四","五","六","七","八","九"};

///唯一复用的函数，根据四个框的选项生成带格式的文本
void Widget::addHtml(int font, int size, int bi, int align, QString content, bool noleft=false, bool noright=false)
{
    if(!noleft){
        //对齐
        if(align == 0){
            html += "<p class=\"txtl\">";
        }
        else if(align == 1){
            html += "<p class=\"txtc\">";
        }
        else if(align == 2){
            html += "<p class=\"txtr\">";
        }
        else qDebug() << "align error";
    }
    html += "<font style=\"";

    //加粗，斜体
    if(bi == 0){

    }
    else if(bi == 1){
        html += "font-weight:bold;";
    }
    else if(bi == 2){
        html += "font-style:italic;";
    }
    else if(bi == 3){
        html += "font-style:italic;";
        html += "font-weight:bold;";
    }
    else qDebug() << "bi error";

    //字号
    switch(size){
    case 0: html += "font-size:42pt;"; break;
    case 1: html += "font-size:36pt;"; break;
    case 2: html += "font-size:26pt;"; break;
    case 3: html += "font-size:24pt;"; break;
    case 4: html += "font-size:22pt;"; break;
    case 5: html += "font-size:18pt;"; break;
    case 6: html += "font-size:16pt;"; break;
    case 7: html += "font-size:15pt;"; break;
    case 8: html += "font-size:14pt;"; break;
    case 9: html += "font-size:12pt;"; break;
    case 10: html += "font-size:10.5pt;"; break;
    case 11: html += "font-size:9pt;"; break;
    case 12: html += "font-size:7.5pt;"; break;
    case 13: html += "font-size:6.5pt;"; break;
    case 14: html += "font-size:5.5pt;"; break;
    case 15: html += "font-size:5pt;"; break;
    default: qDebug() << "size error";
    }

    //字体
    if(font == 0){
        html += "font-family:宋体\">";
    }
    else if(font == 1){
        html += "font-family:楷体\">";
    }
    else if(font == 2){
        html += "font-family:黑体\">";
    }
    else if(font == 3){
        html += "font-family:微软雅黑\">";
    }

    //内容
    html += content;

    //尾部格式
    html += "</font>";
    if(!noright){
        html += "</p>";
    }
}

QString Widget::saveHtml()
{
    QString path;

    ///html头
    html += "<html>";
    html += "<head>";
    html += "<title></title>";
    html += "<meta charset=\"gb2312\">";
    html += "<style type=\"text/css\">";
    html += ".txtc{text-align:center;}.txtr{text-align:right;}.txtl{text-align:left;text-indent:2em;}";
    html += "</style>";
    html += "<head>";
    html += "<body>";

    ///一边读取每部分的内容，一边输出到word文档中
    ///标题
    if(subtitle!="") addHtml(c11,c12,c13,c14,title);
    if(subtitle!="") addHtml(c21,c22,c23,c24,subtitle);
    ///作者
    QString tau="";
    path = prePath+"/author.txt";
    QFile fauthor(path);
    fauthor.open(QIODevice::ReadOnly|QIODevice::Text);
    if(!fauthor.atEnd())
    {
        QByteArray line;
        line = fauthor.readLine();
        QString name(line);
        name = name.left(name.size()-1);
        tau += name;
    }
    if(!fauthor.atEnd())
    {
        QByteArray line;
        line = fauthor.readLine();
        QString job(line);
        job = job.left(job.size()-1);
        tau += " ";
        tau += job;
    }
    if(!fauthor.atEnd())
    {
        QByteArray line;
        line = fauthor.readLine();
        QString num(line);
        num = num.left(num.size()-1);
        tau += " ";
        tau += num;
    }
    if(!fauthor.atEnd())
    {
        QByteArray line;
        line = fauthor.readLine();
        QString els(line);
        els = els.left(els.size()-1);
        tau += " ";
        tau += els;
    }
    addHtml(c31,c32,c33,c34,tau);
    fauthor.close();


    ///摘要
    path = prePath + "/abstract.txt";
    QFile fabs(path);
    bool firstLineAbstract = true;
    fabs.open(QIODevice::ReadOnly|QIODevice::Text);
    while(!fabs.atEnd())
    {
        QByteArray line;
        line = fabs.readLine();
        QString str(line);
        if(str.right(1)=="\n") str = str.left(str.size()-1);
        if(firstLineAbstract){
            addHtml(c41,c42,c43,c44,"摘要：",false,true);
            addHtml(c51,c52,c53,c54,str,true,false);
            firstLineAbstract = false;
        }
        else{
            addHtml(c51,c52,c53,c54,str);
        }
    }
    fabs.close();


    ///关键词
    path = prePath + "/keywords.txt";
    QFile fkey(path); QString allKeywords="";
    fkey.open(QIODevice::ReadOnly|QIODevice::Text);
    while(!fkey.atEnd())
    {
        QByteArray line;
        line = fkey.readLine();
        QString word(line);
        word = word.left(word.size()-1);
        if(allKeywords != ""){
            allKeywords += "；";
        }
        allKeywords += word;
    }
    addHtml(c61,c62,c63,c64,"关键词：",false,true);
    addHtml(c71,c72,c73,c74,allKeywords,true,false);
    fkey.close();

    ///正文
    path = prePath + "/mainbody.txt";
    QFile f4(path);
    f4.open(QIODevice::ReadOnly|QIODevice::Text);

    bool nextisTitle = false;
    while(!f4.atEnd())
    {
        QByteArray line = f4.readLine();
        QString str(line);
        if(str == tr("*\n"))
        {
            break;
        }
        else if(str == tr("#\n"))
        {
            html += "<br>";
            nextisTitle = true;
        }
        else
        {
            if(nextisTitle){
                addHtml(c81,c82,c83,c84, chineseNumber[(str[0].unicode()-'1')%9] + "、" + str.right(str.size()-7));
                nextisTitle = false;
            }
            else{
                addHtml(c91,c92,c93,c94,str);
            }
        }
    }
    f4.close();

    ///参考文献
    html += "<br>";
    addHtml(ca1,ca2,ca3,ca4,"参考文献");
    path = prePath + "/anno.txt";
    QFile fanno(path);
    fanno.open(QIODevice::ReadOnly|QIODevice::Text);
    while(!fanno.atEnd())
    {
        QByteArray line = fanno.readLine();
        QString str(line);
        str = str.left(str.size()-1);
        addHtml(cb1,cb2,cb3,cb4,str);
    }

    fanno.close();


    ///html尾
    html += "</body>";
    html += "</html>";
    return html;
}

///调用saveWord生成word文档
void Widget::saveWord()
{
    ///在这里读取标题和副标题，以作为文件名
    QString path;
    path = prePath+"/title.txt";
    QFile ftitle(path);
    ftitle.open(QIODevice::ReadOnly|QIODevice::Text);
    if(!ftitle.atEnd())
    {
        QByteArray line ;
        line = ftitle.readLine();
        QString name(line);
        title = name.left(name.size()-1);
        addHtml(c11,c12,c13,c14,name);
    }
    else title="";
    if(!ftitle.atEnd())
    {
        QByteArray line ;
        line = ftitle.readLine();
        QString name(line);
        subtitle = name.left(name.size()-1);
        addHtml(c21,c22,c23,c24,name);
    }
    else subtitle="";
    ftitle.close();

    ///生成word文档
    QString docname = prePath+"/"+title+" "+subtitle+".doc";
    saveHtml();
    QFile outFile(docname);
    outFile.open(QIODevice::WriteOnly | QIODevice::Text );
    QTextStream ts(&outFile);
    ts<<html<<endl;
}
