#ifndef KEYWORD_H
#define KEYWORD_H

#include <QDialog>
#include "QListWidgetItem"
namespace Ui {
class KeyWord;
}

class KeyWord : public QDialog
{
    Q_OBJECT

public:
    explicit KeyWord(QWidget *parent = 0);
    ~KeyWord();

private slots:
    void on_Add_Keyword_clicked();
    void on_listWidget_itemClicked(QListWidgetItem *item);

    void on_Delete_Keyword_clicked();

signals:
    void signalSaveClicked();
protected slots:
    void slotSaveClicked();
private:
    Ui::KeyWord *ui;
};

#endif // KEYWORD_H
