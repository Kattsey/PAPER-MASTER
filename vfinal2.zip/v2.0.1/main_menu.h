#ifndef MAIN_MENU_H
#define MAIN_MENU_H

#include <QDialog>
#include"title.h"
#include"abstract.h"
#include"keyword.h"
#include"mainbody.h"
#include"author.h"
#include"create.h"

namespace Ui {
class Main_Menu;
}

class Main_Menu : public QDialog
{
    Q_OBJECT

public:
    explicit Main_Menu(QWidget *parent = 0);
    ~Main_Menu();
    void showInfo();
private slots:
    void on_title_clicked();

    void on_author_clicked();

    void on_abstract_2_clicked();

    void on_Keyword_clicked();

    void on_Main_body_clicked();

    void on_create_clicked();

    void on_close_clicked();

protected slots:
    void titleSaveReceiveSignal();

    void authorSaveReceiveSignal();

    void abstractSaveReceiveSignal();

    void keySaveReceiveSignal();

    void bodySaveReceiveSignal();


private:
    Ui::Main_Menu *ui;
};

#endif // MAIN_MENU_H
