#include "abstract.h"
#include "ui_abstract.h"
#include "variate.h"
#include "QFile"
#include "QTextStream"
#include <QDebug>

Abstract::Abstract(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Abstract)
{
    ui->setupUi(this);
    //——————————————————————————————————————————
    this->setWindowTitle("摘要");
    connect(ui->save,SIGNAL(clicked()),this,SLOT(slotSaveClicked()));
    QString path;
    path = prePath + "/abstract.txt";
    QFile f(path);
    f.open(QIODevice::ReadOnly|QIODevice::Text);
    while(!f.atEnd())
    {
        QByteArray line;
        line = f.readLine();
        QString str(line);
        //qDebug()<<str.right(1);
        if(str.right(1)=="\n") str = str.left(str.size()-1);
        ui->textEdit->append(str);
    }
    f.close();
}

Abstract::~Abstract()
{
    delete ui;
}
void Abstract::slotSaveClicked()
{
    QString path;
    path = prePath + "/abstract.txt";
    QFile f(path);
    f.open(QIODevice::WriteOnly|QIODevice::Text);
    QTextStream out(&f);
    out.setCodec("utf-8");
    QString str;
    str = ui->textEdit->toPlainText();
    out<<str;
    f.close();
    emit signalSaveClicked();
    this->close();
}
