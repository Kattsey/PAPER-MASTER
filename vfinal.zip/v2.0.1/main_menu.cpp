#include "main_menu.h"
#include "ui_main_menu.h"
#include "mainwindow.h"
#include "variate.h"
#include "QFile"
#include "QDebug"

Main_Menu::Main_Menu(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Main_Menu)
{

    ui->setupUi(this);
    //——————————————————————————————————————————————————————————————————
    this->setWindowTitle("主界面");
    ui->textBrowser->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    showInfo();

}

Main_Menu::~Main_Menu()
{
    delete ui;
}
void Main_Menu::titleSaveReceiveSignal()
{
    showInfo();
}

void Main_Menu::on_title_clicked()
{
    Title* title=new Title();
    connect(title,&Title::signalSaveClicked,this,&Main_Menu::titleSaveReceiveSignal);
    title->exec();
}

void Main_Menu::authorSaveReceiveSignal()
{
    showInfo();
}

void Main_Menu::on_author_clicked()
{
    Author* author=new Author();
    connect(author,&Author::signalSaveClicked,this,&Main_Menu::authorSaveReceiveSignal);
    author->exec();
}
void Main_Menu::abstractSaveReceiveSignal()
{
    showInfo();
}

void Main_Menu::on_abstract_2_clicked()
{
    Abstract* abstract = new Abstract();
    connect(abstract,&Abstract::signalSaveClicked,this,&Main_Menu::abstractSaveReceiveSignal);
    abstract->exec();
}
void Main_Menu::keySaveReceiveSignal()
{
    showInfo();
}

void Main_Menu::on_Keyword_clicked()
{
    KeyWord* keywords = new KeyWord();
    connect(keywords,&KeyWord::signalSaveClicked,this,&Main_Menu::keySaveReceiveSignal);
    keywords->exec();
}

void Main_Menu::bodySaveReceiveSignal()
{
    showInfo();
}

void Main_Menu::on_Main_body_clicked()
{
    Mainbody* mainbody = new Mainbody();
    connect(mainbody,&Mainbody::signalSaveClicked,this,&Main_Menu::bodySaveReceiveSignal);
    mainbody->exec();
}


void Main_Menu::on_create_clicked()
{
    Create* create = new Create();
    create->exec();


}
void Main_Menu::showInfo()
{
    ui->textBrowser->setFont(QFont("times"));
    ui->textBrowser->setText("<font size=7>"+tr("以下为您的论文预览...")+"</font>");
    ui->textBrowser->append("\n");
    ui->textBrowser->setAlignment(Qt::AlignCenter);
    //读取标题文件
    QString path ;
    path= prePath+"/title.txt";
    QFile f(path);
    f.open(QIODevice::ReadOnly|QIODevice::Text);
    QString mainName("");
    QString secName("");
    if(!f.atEnd())
    {
        QByteArray line = f.readLine();
        mainName=tr(line);
        mainName = mainName.left(mainName.size()-1);
    }
    if(!f.atEnd())
    {
        QByteArray line = f.readLine();
        secName=tr(line);
        secName = secName.left(secName.size()-1);
    }
   // ui->textBrowser->setAlignment(Qt::AlignCenter);
    ui->textBrowser->append(tr("······标题······"));

    ui->textBrowser->append(tr("<主标题>"));
    if(mainName.size()) ui->textBrowser->append(mainName);
    else
        ui->textBrowser->append(tr("无"));
    ui->textBrowser->append(tr("<副标题>"));
    if(secName.size()) ui->textBrowser->append(secName);
    else ui->textBrowser->append(tr("无"));
    f.close();
    //读取作者文件
    QString name(""),job(""),num(""),els("");
    //ui->textBrowser->setAlignment(Qt::AlignCenter);
    ui->textBrowser->append(tr("······作者······"));
    ui->textBrowser->append(tr("<姓名>"));
    path = prePath+"/author.txt";
    QFile f1(path);
    f1.open(QIODevice::ReadOnly|QIODevice::Text);
    if(!f1.atEnd())
    {
        QByteArray line;
        line = f1.readLine();
        name = tr(line);
        name = name.left(name.size()-1);

    }
    if(name.size()) ui->textBrowser->append(name);
    else ui->textBrowser->append(tr("无"));
    ui->textBrowser->append(tr("<工作>"));
    if(!f1.atEnd())
    {
        QByteArray line;
        line = f1.readLine();
        job = tr(line);
        job = job.left(job.size()-1);

    }
    if(job.size()) ui->textBrowser->append(job);
    else ui->textBrowser->append(tr("无"));
    ui->textBrowser->append(tr("<编号>"));
    if(!f1.atEnd())
    {
        QByteArray line;
        line = f1.readLine();
        num = tr(line);
        num = num.left(num.size()-1);

    }
    if(num.size()) ui->textBrowser->append(num);
    else ui->textBrowser->append(tr("无"));
    ui->textBrowser->append(tr("<其它>"));
    if(!f1.atEnd())
    {
        QByteArray line;
        line = f1.readLine();
        els = tr(line);
        els = els.left(els.size()-1);

    }
    if(els.size()) ui->textBrowser->append(els);
    else ui->textBrowser->append(tr("无"));
    f1.close();
    //获取abstract
    path = prePath + "/abstract.txt";
    QFile f2(path);
    f2.open(QIODevice::ReadOnly|QIODevice::Text);
    ui->textBrowser->setAlignment(Qt::AlignCenter);
    ui->textBrowser->append(tr("······摘要······"));
    if(f2.atEnd())
    {
        ui->textBrowser->setAlignment(Qt::AlignCenter);
        ui->textBrowser->append(tr("无"));
        ui->textBrowser->setAlignment(Qt::AlignLeft);
    }
    ui->textBrowser->setAlignment(Qt::AlignLeft);
    while(!f2.atEnd())
    {
        QByteArray line = f2.readLine();
        QString str(line);
        if(str.at(str.size()-1)==tr("\n"))
            str = str.left(str.size()-1);
        ui->textBrowser->append(str);
    }
    f2.close();
    //获取keywords
    path = prePath + "/keywords.txt";
    QFile f3(path);
    f3.open(QIODevice::ReadOnly|QIODevice::Text);
    ui->textBrowser->setAlignment(Qt::AlignCenter);
    ui->textBrowser->append(tr("······关键词······"));
    QString words("");
    int s=1;
    if(f3.atEnd()) ui->textBrowser->append(tr("无"));
    while(!f3.atEnd())
    {
        words += tr("<");
        words += QString::number(s,10);
        words += tr(">");
        QByteArray line = f3.readLine();
        QString str(line);
        str = str.left(str.size()-1);
        words+=str;++s;
    }
    if(words.size())
        ui->textBrowser->append(words);
    f3.close();
    ui->textBrowser->setAlignment(Qt::AlignLeft);
    //获取正文
    path = prePath + "/mainbody.txt";
    QFile f4(path);
    f4.open(QIODevice::ReadOnly|QIODevice::Text);
    ui->textBrowser->setAlignment(Qt::AlignCenter);
    ui->textBrowser->append(tr("······正文······"));
    QString cont("");
    ui->textBrowser->setAlignment(Qt::AlignLeft);
    while(!f4.atEnd())
    {
        QByteArray line = f4.readLine();
        QString str(line);
        str = str.left(str.size()-1);

        if(str == tr("#"))
        {
            if(cont.size()) ui->textBrowser->append(cont);
            line = f4.readLine();
            QString t(line);
            t = t.left(t.size()-1);
            ui->textBrowser->setAlignment(Qt::AlignCenter);
            ui->textBrowser->append(tr("段落") + t);
            ui->textBrowser->setAlignment(Qt::AlignLeft);
            cont = tr("");
        }
        else if(str == tr("*"))
        {
            if(cont.size()) ui->textBrowser->append(cont); break;
        }

        else
            cont +=str;
    }

    f4.close();
    //获取注释
    path = prePath + "/anno.txt";
    QFile f5(path);
    f5.open(QIODevice::ReadOnly|QIODevice::Text);
    QString lines("");
    while(!f5.atEnd())
    {
        QByteArray line = f5.readLine();
        QString l(line);
        lines += l;
    }
    ui->textBrowser->setAlignment(Qt::AlignCenter);
    ui->textBrowser->append(tr("······注释······"));

    if(!lines.size()) ui->textBrowser->append(tr("无"));

    else
    {
        ui->textBrowser->setAlignment(Qt::AlignLeft);
        lines = lines.left(lines.size()-1);
        ui->textBrowser->append(lines);
    }

    return;
}

void Main_Menu::on_close_clicked()
{
    this->close();


}
