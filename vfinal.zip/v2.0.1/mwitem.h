#ifndef MWITEM_H
#define MWITEM_H

#include <QWidget>

namespace Ui {
class MWitem;
}

class MWitem : public QWidget
{
    Q_OBJECT

public:
    explicit MWitem(QWidget *parent = 0);
    ~MWitem();
    //初始化
    void Init(QString name,QString path);
    void OnSelect();
    void OnRelease();
    QString lb2();
private:

    Ui::MWitem *ui;
};

#endif // MWITEM_H


