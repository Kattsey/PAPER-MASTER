#include "title.h"
#include "ui_title.h"
#include "variate.h"
#include "QFile"
#include "QTextStream"
#include "QDebug"
Title::Title(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Title)
{
    ui->setupUi(this);
    //————————————————————————————————
    this->setWindowTitle("标题");
    connect(ui->Save,SIGNAL(clicked()),this,SLOT(slotSaveClicked()));

    QString path;
    path = prePath+"/title.txt";
    QFile f(path);
    f.open(QIODevice::ReadOnly|QIODevice::Text);
    if(!f.atEnd())
    {
        QByteArray line ;
        line = f.readLine();
        QString name(line);
        name = name.left(name.size()-1);
        ui->main_title->setText(name);
    }
    if(!f.atEnd())
    {
        QByteArray line ;
        line = f.readLine();
        QString name(line);
        name = name.left(name.size()-1);
        ui->sec_title->setText(name);
    }
    f.close();
}

Title::~Title()
{
    delete ui;
}

void Title::slotSaveClicked()
{
    QString path;
    path = prePath+"/title.txt";
    QFile f(path);
    f.open(QIODevice::WriteOnly|QIODevice::Text);
    QTextStream out(&f);
    out.setCodec("utf-8");
    QString p;
    p = ui->main_title->text();
    if(p.size())
        out<<p<<endl;
    else out<<endl;
    p = ui->sec_title->text();
    if(p.size())
        out<<p<<endl;
    else out<<endl;
    f.close();
    emit signalSaveClicked();
    this->close();
}


