#ifndef MODIFY_ANNO_H
#define MODIFY_ANNO_H

#include <QDialog>
#include "QListWidgetItem"
namespace Ui {
class Modify_anno;
}

class Modify_anno : public QDialog
{
    Q_OBJECT

public:
    explicit Modify_anno(QWidget *parent = 0);
    ~Modify_anno();
    QListWidgetItem* select=nullptr;
private slots:

    void on_conv_delete_clicked();

    void on_listWidget_itemClicked(QListWidgetItem *item);

    void on_conv_modify_clicked();

    void on_add_clicked();
protected slots:
    void slotSaveClicked();

private:
    Ui::Modify_anno *ui;
};

#endif // MODIFY_ANNO_H
