#include "mainbody.h"
#include "ui_mainbody.h"
#include "variate.h"
#include "QListWidgetItem"
#include "QString"
#include "QTextStream"
Mainbody::Mainbody(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Mainbody)
{
    ui->setupUi(this);
    ui->show->setSortingEnabled(true);
    this->setWindowTitle("正文");
    ui->topic_text->setPlaceholderText("请输入文段标题...");
    ui->textEdit->setPlaceholderText("请输入文段内容...");
    //ui->show->setResizeMode(QListWidget::Adjust);
    // 设置为列表显示模式
    ui->show->setViewMode(QListView::ListMode);
    // 设置从上到下排列
    ui->show->setFlow(QListView::TopToBottom);
    // 屏蔽水平滑动条
    ui->show->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    // 屏蔽垂直滑动条
    ui->show->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    // 设置成像素滚动
    ui->show->setHorizontalScrollMode(QListWidget::ScrollPerPixel);
    ui->show->setVerticalScrollMode(QListWidget::ScrollPerPixel);
    //设置可以换行显示
    ui->show->setLayoutMode(QListWidget::Batched);
    // 设置自动换行
    ui->show->setWordWrap(true);

    //初始化列表
    QString path = prePath + "/mainbody.txt";
    QFile f4(path);
    f4.open(QIODevice::ReadOnly|QIODevice::Text);
    QString all("");
    int cnt=0;
    while(!f4.atEnd())
    {
        QByteArray line = f4.readLine();
        QString str(line);
        if(str == tr("*\n"))
        {
            if(cnt==0) break;
            all = all.left(all.size()-1);
            QListWidgetItem* item = new QListWidgetItem(ui->show);
            item->setText(all);
            break;
        }
        else if(str == tr("#\n"))
        {
            cnt++;
            if(all.size())
            {
                all = all.left(all.size()-1);
                QListWidgetItem* item = new QListWidgetItem(ui->show);
                item->setText(all);all = tr("");
            }
        }
        else
            all +=str;
    }
    f4.close();
    connect(ui->save,SIGNAL(clicked()),this, SLOT(slotSaveClicked()) );
}


Mainbody::~Mainbody()
{
    delete ui;
}



void Mainbody::on_modify_anno_clicked()
{
    Modify_anno modify_anno;
    modify_anno.exec();
}

void Mainbody::on_add_clicked()
{
    QString topic,content;
    topic = ui->topic_text->text();
    content = ui->textEdit->toPlainText();
    int num = ui->spinBox->value();
    QString Num = QString::number(num,10);
    if(topic.size()==0&&content.size()==0) return;
    if(topic.size()==0)
    {
        topic = Num + tr(" 暂无标题");
    }
    else
    {
        topic = Num;
        topic += tr(" 段落标题：");
        topic += ui->topic_text->text();
    }
    if(content.size()==0) content = tr("暂无内容");



    QListWidgetItem* item = new QListWidgetItem(ui->show);
    QString all = topic + tr("\n") + content;
    item->setText(all);
    ui->show->sortItems();
    ui->topic_text->clear();
    ui->textEdit->clear();
}

void Mainbody::on_show_itemClicked(QListWidgetItem *item)
{
    select = item;
}

void Mainbody::on_delete_2_clicked()
{
    delete select;
    select = nullptr;
}

void Mainbody::on_operate_clicked()
{
    if(select==nullptr) return;
    on_add_clicked();
    QString all = select->text();
    int pos = all.indexOf("\n");
    QString topic = all.mid(0,pos);
    QString content = all.mid(pos+1,all.size()-pos-1);
    int pos2 = topic.indexOf(tr(" "));
    bool ok=false;
    int num = topic.mid(0,pos2).toInt(&ok,10);
    topic = topic.mid(pos2+6);
    ui->spinBox->setValue(num);
    ui->topic_text->setText(topic);
    ui->textEdit->setText(content);
    delete select;
    select = nullptr;
}

void Mainbody::slotSaveClicked()
{
    on_add_clicked();
    QString path;
    path = prePath + "/mainbody.txt";
    QFile f(path);
    f.open(QIODevice::WriteOnly|QIODevice::Text);
    QTextStream out(&f);
    out.setCodec("utf-8");
    int row=0;
    while(row<(ui->show->count()))
    {
        out<<tr("#")<<endl;
        QListWidgetItem* item = ui->show->item(row);
        QString s = item->text();
        int pos = s.indexOf(tr("\n"));
        QString topic,content;
        topic = s.mid(0,pos);
        content = s.mid(pos+1);
        out<<topic<<endl;
        out<<content<<endl;
        row++;
    }
    out<<tr("*")<<endl;
    f.close();
    emit signalSaveClicked();
    this->close();
}
