#include "create_dialog.h"
#include "ui_create_dialog.h"
#include<QPushButton>
#include<QFileDialog>
#include<QString>
#include "QDebug"
#include "variate.h"
#include "QFile"
#include "qtextcodec.h"
#include "QTextStream"
Create_Dialog::Create_Dialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Create_Dialog)
{
    ui->setupUi(this);
    this->setWindowTitle("创建新的项目");

    //—————————————————————————————————————————————————————————
    /*ui->Paper_name->setStyleSheet("font: 25 10pt '微软雅黑 Light';" //字体
                                    "color: rgb(31,31,31);"		//字体颜色
                                    "padding-left:20px;"       //内边距-字体缩进
                                    "background-color: rgb(255, 255, 255);" //背景颜色
                                    "border:2px solid rgb(20,196,188);border-radius:15px;");//边框粗细-颜色-圆角设置
    ui->save_line->setStyleSheet("font: 25 10pt '微软雅黑 Light';" //字体
                                    "color: rgb(31,31,31);"		//字体颜色
                                    "padding-left:20px;"       //内边距-字体缩进
                                    "background-color: rgb(255, 255, 255);" //背景颜色
                                    "border:2px solid rgb(20,196,188);border-radius:15px;");//边框粗细-颜色-圆角设置
    //——————————————————————————————————————————————————————————
    ui->Create->setStyleSheet("QPushButton{font: 25 14pt '微软雅黑 Light';color: rgb(255,255,255);background-color: rgb(20,196,188);"
                                     "border: 2px groove gray;border-radius:15px;padding:2px 4px;border-style: outset;}"
                                     "QPushButton:hover{background-color: rgb(22,218,208);}"//hover
                                     "QPushButton:pressed{background-color: rgb(17,171,164);}"//pressed
                                       "border:2px solid rgb(20,196,188);");
    ui->Back->setStyleSheet("QPushButton{font: 30 14pt '微软雅黑 Light';color: rgb(255,255,255);background-color: rgb(20,196,188);"
                                     "border: 2px groove gray;border-radius:15px;padding:2px 4px;border-style: outset;}"
                                     "QPushButton:hover{background-color: rgb(22,218,208);}"//hover
                                     "QPushButton:pressed{background-color: rgb(17,171,164);}"//pressed
                                       "border:2px solid rgb(20,196,188);");
    ui->viewFile->setStyleSheet(//"QToolButton{font: 25 14pt '微软雅黑 Light';color: rgb(255,255,255);background-color: rgb(20,196,188);"
                                     "border: 2px groove gray;border-radius:15px;padding:2px 4px;border-style: outset;}"
                                     "QToolButton:hover{background-color: rgb(22,218,208);}"//hover
                                     "QToolButton:pressed{background-color: rgb(17,171,164);}"//pressed
                                       "border:2px solid rgb(20,196,188);");*/
    //——————————————————————————————————————————————————————————————————
    //this->setStyleSheet("background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0, stop:0 rgba(120,120,120, 200), stop:1 rgba(120,120,120, 200));");
    ui->Paper_name->setPlaceholderText("请输入项目名称");
    ui->save_line->setPlaceholderText("请选择项目所在文件夹");
    ui->save_line->setReadOnly(true);
    ui->label_3->setText("");
    ui->label_2->setText("<font size=3 color=black>文件名称</font>");
    ui->label->setText("<font size=3 color=black>保存路径</font>");
}

Create_Dialog::~Create_Dialog()
{
    delete ui;
}

void Create_Dialog::on_Create_clicked()
{
    ui->label_3->setText("");
    QString path = ui->save_line->text();
    QString name = ui->Paper_name->text();
    // 获取所有文件夹名
    QDir dir(path);
    QStringList folders;
    if (!dir.exists()) folders = QStringList("");
    dir.setFilter(QDir::Dirs | QDir::NoDotAndDotDot);
    dir.setSorting(QDir::Name);
    folders = dir.entryList();
    for (int i = 0; i < folders.size(); ++i)
    {
        if(folders[i]==name)
        {
            ui->label_3->setText("该文件名已存在");
            return;
        }
    }
    QDir project(path);
    project.mkpath(path +'/'+ name);
    file.open(QIODevice::ReadWrite|QIODevice::Append|QIODevice::Text);
    QTextStream out(&file);
    QTextCodec *code=QTextCodec::codecForName("utf-8");
    out.setCodec(code);
    out<<name<<endl;
    out<<path+'/'+name<<endl;
    preName=name;
    prePath=path+'/'+name;
    file.close();
    Main_Menu mainmenu;
    this->close();
    mainmenu.exec();
}

void Create_Dialog::on_Back_clicked()
{
    back=true;
    this->close();
}

void Create_Dialog::on_viewFile_clicked()
{
    QString fpath=QFileDialog::getExistingDirectory(
                this, "选择项目存储地址",
                 "/");
    ui->save_line->setText(fpath);
}
