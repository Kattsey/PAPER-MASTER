#ifndef VARIATE_H
#define VARIATE_H

#include "QString"
#include "QFile"
#include "mainwindow.h"

extern QString dirPath;
extern QString prePath;
extern QString preName;
extern QFile file;
extern bool hasSelected;
extern qreal fac;

#endif // VARIATE_H
