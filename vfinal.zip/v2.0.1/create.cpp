#include "create.h"
#include "ui_create.h"
#include "variate.h"
#include "widget.h"
#include "QFile"
#include "QTextStream"
#include "QDebug"
#include "Qsize"
#include "widget.h"
#include "ui_widget.h"

Create::Create(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Create)
{
    ui->setupUi(this);
    this->setStyleSheet("background-color:pink");

    //按（某个）论文标准格式设置默认值
    //字体
    ui->c11->setCurrentIndex(2);
    ui->c21->setCurrentIndex(2);
    ui->c31->setCurrentIndex(2);
    ui->c41->setCurrentIndex(2);
    ui->c51->setCurrentIndex(0);
    ui->c61->setCurrentIndex(2);
    ui->c71->setCurrentIndex(0);
    ui->c81->setCurrentIndex(2);
    ui->c91->setCurrentIndex(0);
    ui->ca1->setCurrentIndex(0);
    ui->cb1->setCurrentIndex(0);
    //字号
    ui->c12->setCurrentIndex(4);
    ui->c22->setCurrentIndex(6);
    ui->c32->setCurrentIndex(6);
    ui->c42->setCurrentIndex(8);
    ui->c52->setCurrentIndex(9);
    ui->c62->setCurrentIndex(8);
    ui->c72->setCurrentIndex(9);
    ui->c82->setCurrentIndex(6);
    ui->c92->setCurrentIndex(9);
    ui->ca2->setCurrentIndex(9);
    ui->cb2->setCurrentIndex(10);
    //加粗
    ui->c13->setCurrentIndex(1);
    ui->c23->setCurrentIndex(1);
    ui->c33->setCurrentIndex(0);
    ui->c43->setCurrentIndex(1);
    ui->c53->setCurrentIndex(0);
    ui->c63->setCurrentIndex(1);
    ui->c73->setCurrentIndex(0);
    ui->c83->setCurrentIndex(1);
    ui->c93->setCurrentIndex(0);
    ui->ca3->setCurrentIndex(1);
    ui->cb3->setCurrentIndex(0);
    //对齐
    ui->c14->setCurrentIndex(1);
    ui->c24->setCurrentIndex(1);
    ui->c34->setCurrentIndex(1);
    ui->c44->setCurrentIndex(0);
    ui->c54->setCurrentIndex(0);
    ui->c64->setCurrentIndex(0);
    ui->c74->setCurrentIndex(0);
    ui->c84->setCurrentIndex(1);
    ui->c94->setCurrentIndex(0);
    ui->ca4->setCurrentIndex(0);
    ui->cb4->setCurrentIndex(0);
    //widget格式
    ui->c11->view()->setIconSize(QSize(50,50));
    ui->c12->view()->setIconSize(QSize(50,50));
    ui->c14->view()->setIconSize(QSize(50,50));
    ui->c21->view()->setIconSize(QSize(50,50));
    ui->c22->view()->setIconSize(QSize(50,50));
    ui->c24->view()->setIconSize(QSize(50,50));
    ui->c31->view()->setIconSize(QSize(50,50));
    ui->c32->view()->setIconSize(QSize(50,50));
    ui->c34->view()->setIconSize(QSize(50,50));
    ui->c41->view()->setIconSize(QSize(50,50));
    ui->c42->view()->setIconSize(QSize(50,50));
    ui->c44->view()->setIconSize(QSize(50,50));
    ui->c51->view()->setIconSize(QSize(50,50));
    ui->c52->view()->setIconSize(QSize(50,50));
    ui->c54->view()->setIconSize(QSize(50,50));
    ui->c61->view()->setIconSize(QSize(50,50));
    ui->c62->view()->setIconSize(QSize(50,50));
    ui->c64->view()->setIconSize(QSize(50,50));
    ui->c71->view()->setIconSize(QSize(50,50));
    ui->c72->view()->setIconSize(QSize(50,50));
    ui->c74->view()->setIconSize(QSize(50,50));
    ui->c81->view()->setIconSize(QSize(50,50));
    ui->c82->view()->setIconSize(QSize(50,50));
    ui->c84->view()->setIconSize(QSize(50,50));
    ui->c91->view()->setIconSize(QSize(50,50));
    ui->c92->view()->setIconSize(QSize(50,50));
    ui->c94->view()->setIconSize(QSize(50,50));
    ui->ca1->view()->setIconSize(QSize(50,50));
    ui->ca2->view()->setIconSize(QSize(50,50));
    ui->ca4->view()->setIconSize(QSize(50,50));
    ui->cb1->view()->setIconSize(QSize(50,50));
    ui->cb2->view()->setIconSize(QSize(50,50));
    ui->cb4->view()->setIconSize(QSize(50,50));
    ui->c13->view()->setIconSize(QSize(50,50));
    ui->c23->view()->setIconSize(QSize(50,50));
    ui->c33->view()->setIconSize(QSize(50,50));
    ui->c43->view()->setIconSize(QSize(50,50));
    ui->c53->view()->setIconSize(QSize(50,50));
    ui->c63->view()->setIconSize(QSize(50,50));
    ui->c73->view()->setIconSize(QSize(50,50));
    ui->c83->view()->setIconSize(QSize(50,50));
    ui->c93->view()->setIconSize(QSize(50,50));
    ui->ca3->view()->setIconSize(QSize(50,50));
    ui->cb3->view()->setIconSize(QSize(50,50));


    connect(ui->createButton,SIGNAL(clicked()),this,SLOT(slotCreateClicked()));

    connect(ui->cancelButton,QPushButton::clicked,this,this->close);

}

Create::~Create()
{
    delete ui;
}

void Create::slotCreateClicked()
{
    Widget* cword = new Widget;
    cword->c11 = ui->c11->currentIndex();
    cword->c21 = ui->c21->currentIndex();
    cword->c31 = ui->c31->currentIndex();
    cword->c41 = ui->c41->currentIndex();
    cword->c51 = ui->c51->currentIndex();
    cword->c61 = ui->c61->currentIndex();
    cword->c71 = ui->c71->currentIndex();
    cword->c81 = ui->c81->currentIndex();
    cword->c91 = ui->c91->currentIndex();
    cword->ca1 = ui->ca1->currentIndex();
    cword->cb1 = ui->cb1->currentIndex();
    cword->c12 = ui->c12->currentIndex();
    cword->c22 = ui->c22->currentIndex();
    cword->c32 = ui->c32->currentIndex();
    cword->c42 = ui->c42->currentIndex();
    cword->c52 = ui->c52->currentIndex();
    cword->c62 = ui->c62->currentIndex();
    cword->c72 = ui->c72->currentIndex();
    cword->c82 = ui->c82->currentIndex();
    cword->c92 = ui->c92->currentIndex();
    cword->ca2 = ui->ca2->currentIndex();
    cword->cb2 = ui->cb2->currentIndex();
    cword->c13 = ui->c13->currentIndex();
    cword->c23 = ui->c23->currentIndex();
    cword->c33 = ui->c33->currentIndex();
    cword->c43 = ui->c43->currentIndex();
    cword->c53 = ui->c53->currentIndex();
    cword->c63 = ui->c63->currentIndex();
    cword->c73 = ui->c73->currentIndex();
    cword->c83 = ui->c83->currentIndex();
    cword->c93 = ui->c93->currentIndex();
    cword->ca3 = ui->ca3->currentIndex();
    cword->cb3 = ui->cb3->currentIndex();
    cword->c14 = ui->c14->currentIndex();
    cword->c24 = ui->c24->currentIndex();
    cword->c34 = ui->c34->currentIndex();
    cword->c44 = ui->c44->currentIndex();
    cword->c54 = ui->c54->currentIndex();
    cword->c64 = ui->c64->currentIndex();
    cword->c74 = ui->c74->currentIndex();
    cword->c84 = ui->c84->currentIndex();
    cword->c94 = ui->c94->currentIndex();
    cword->ca4 = ui->ca4->currentIndex();
    cword->cb4 = ui->cb4->currentIndex();

    cword->saveWord();
    this->close();
}
void Create::slotCancelClicked()
{



}
