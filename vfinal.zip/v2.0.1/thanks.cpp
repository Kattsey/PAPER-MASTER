#include "thanks.h"
#include "ui_thanks.h"

Thanks::Thanks(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Thanks)
{
    ui->setupUi(this);
    //——————————————————————————————————
    ui->Clear->setStyleSheet("QPushButton{font: 25 14pt '微软雅黑 Light';color: rgb(255,255,255);background-color: rgb(20,196,188);"
                                     "border: 2px groove gray;border-radius:15px;padding:2px 4px;border-style: outset;}"
                                     "QPushButton:hover{background-color: rgb(22,218,208);}"//hover
                                     "QPushButton:pressed{background-color: rgb(17,171,164);}"//pressed
                                       "border:2px solid rgb(20,196,188);");
    ui->Save->setStyleSheet("QPushButton{font: 25 14pt '微软雅黑 Light';color: rgb(255,255,255);background-color: rgb(20,196,188);"
                                     "border: 2px groove gray;border-radius:15px;padding:2px 4px;border-style: outset;}"
                                     "QPushButton:hover{background-color: rgb(22,218,208);}"//hover
                                     "QPushButton:pressed{background-color: rgb(17,171,164);}"//pressed
                                       "border:2px solid rgb(20,196,188);");
    this->setStyleSheet("background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0, stop:0 rgba(120,120,120, 200), stop:1 rgba(120,120,120, 200));");
}

Thanks::~Thanks()
{
    delete ui;
}
