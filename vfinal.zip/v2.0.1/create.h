#ifndef CREATE_H
#define CREATE_H

#include <QDialog>

namespace Ui {
class Create;
}

class Create : public QDialog
{
    Q_OBJECT

public:
    explicit Create(QWidget *parent = 0);
    ~Create();

signals:
    void signalCreateClicked();
protected slots:
    void slotCreateClicked();
    void slotCancelClicked();


private:
    Ui::Create *ui;
};

#endif // CREATE_H
