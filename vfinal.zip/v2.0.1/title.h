#ifndef TITLE_H
#define TITLE_H

#include <QDialog>

namespace Ui {
class Title;
}

class Title : public QDialog
{
    Q_OBJECT

public:
    explicit Title(QWidget *parent = 0);
    ~Title();
signals:
    void signalSaveClicked();
protected slots:
    void slotSaveClicked();


private:
    Ui::Title *ui;
};

#endif // TITLE_H
