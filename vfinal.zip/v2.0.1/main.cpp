#include "mainwindow.h"
#include"create_dialog.h"
#include"main_menu.h"
#include"title.h"
#include"author.h"
#include"abstract.h"
#include"modify_anno.h"
#include"annotation.h"
#include"keyword.h"
#include"thanks.h"
#include"mainbody.h"
#include "variate.h"

#include <QApplication>
#include<QFile>
#include<QDebug>
#include <windows.h>
#include "winuser.h"


int main(int argc, char *argv[])
{
    DEVMODE NewDevMode;
    EnumDisplaySettings(0,ENUM_CURRENT_SETTINGS,&NewDevMode);
    qreal cx = NewDevMode.dmPelsWidth;
    qreal scale = cx/1920;
    qDebug()<<scale<<endl;
    if(scale<1.0) scale = 1.0;
    fac = scale;
    qputenv("QT_SCALE_FACTOR",QString::number(scale).toLatin1());
    QApplication a(argc, argv);
    MainWindow startpage;
    startpage.show();
    QFile file(":/main.qss");
    file.open(QFile::ReadOnly);
    if(file.isOpen())
    {
        qApp->setStyleSheet(file.readAll());
    }
    else
    {
        qDebug()<<"failed in openning";
    }




    return a.exec();
}
