#ifndef MAINBODY_H
#define MAINBODY_H

#include <QDialog>
#include"annotation.h"
#include"modify_anno.h"
#include "QListWidgetItem"

namespace Ui {
class Mainbody;
}

class Mainbody : public QDialog
{
    Q_OBJECT

public:
    explicit Mainbody(QWidget *parent = 0);
    ~Mainbody();
    QListWidgetItem* select = nullptr;

private slots:

    void on_modify_anno_clicked();

    void on_add_clicked();

    void on_show_itemClicked(QListWidgetItem *item);

    void on_delete_2_clicked();

    void on_operate_clicked();
protected slots:
    void slotSaveClicked();
signals:
    void signalSaveClicked();
private:
    Ui::Mainbody *ui;
};

#endif // MAINBODY_H
