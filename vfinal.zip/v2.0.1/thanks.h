#ifndef THANKS_H
#define THANKS_H

#include <QDialog>

namespace Ui {
class Thanks;
}

class Thanks : public QDialog
{
    Q_OBJECT

public:
    explicit Thanks(QWidget *parent = 0);
    ~Thanks();

private:
    Ui::Thanks *ui;
};

#endif // THANKS_H
